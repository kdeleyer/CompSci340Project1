#include <iostream>
using namespace std;

// Function to perform scalar matrix multiplication
void scalarmatmult(const int n, const double* const* A, double b, double** C) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            C[i][j] = A[i][j] * b;
        }
    }
}

int main() {
    const int n = 3; // Size of the matrix
    double A[n][n] = {{1, 2, 3},
                      {4, 5, 6},
                      {7, 8, 9}};
    double b = 2; // Scalar value
    double C[n][n]; // Resultant matrix
    
    // Perform scalar matrix multiplication
    scalarmatmult(n, (const double* const*)A, b, (double**)C);
    
    // Display the result
    cout << "Resultant Matrix:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << C[i][j] << " ";
        }
        cout << endl;
    }
    
    return 0;
}
