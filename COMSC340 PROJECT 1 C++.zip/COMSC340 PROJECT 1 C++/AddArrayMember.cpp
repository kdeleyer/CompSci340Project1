#include <iostream>
using namespace std;

// Function to compute the sum of elements in an array
double number_sum(int n, const double S[]) {
    double result = 0;
    for (int i = 0; i < n; i++) {
        result += S[i];
    }
    return result;
}

int main() {
    const int n = 5; // Size of the array
    double S[n] = {1.5, 2.3, 3.7, 4.1, 5.9}; // Array of numbers
    
    // Compute the sum of elements in the array
    double sum = number_sum(n, S);
    
    // Display the result
    cout << "Sum of elements in the array: " << sum << endl;
    
    return 0;
}
